package com.application.DAO;

import com.application.Models.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class CustomRepoImpl implements CustomRepo{

    @Autowired
    private JdbcTemplate jdbc;

    public List<Person> findAll() {
        String sql = "SELECT * from PERSON";
        return jdbc.query(sql,new CustomRowMapper());
    }

    @Override
    public Person findById(Integer id) {
        String sql = "SELECT * FROM PERSON WHERE ID = ?";
        try {
            return jdbc.queryForObject(sql, new Object[]{id}, new CustomRowMapper());
        }
        catch (Exception e){
            System.out.println("No such Records Exist !!");
            return null;
        }
    }

    @Override
    public List<Person> updatePerson(Integer id,Person p) {
        String sql = "UPDATE PERSON SET NAME = ? WHERE ID = ?";
        jdbc.update(sql,new Object[]{p.getName(),id});
        return findAll();
    }

    @Override
    public List<Person> insertPerson(Person p) {
        String sql = "INSERT INTO PERSON VALUES(?,?);";
        jdbc.update(sql,new Object[]{p.getId(),p.getName()});
        return findAll();
    }
}

class CustomRowMapper implements RowMapper<Person>{

    @Override
    public Person mapRow(ResultSet rs, int i) throws SQLException {
        Person person = new Person();
        person.setId(rs.getInt("id"));
        person.setName(rs.getString("name"));
        return person;
    }
}
