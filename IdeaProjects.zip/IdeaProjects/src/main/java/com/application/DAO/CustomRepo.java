package com.application.DAO;


import com.application.Models.Person;

import java.util.List;

public interface CustomRepo {
    List<Person> findAll();
    Person findById(Integer id);
    List<Person> insertPerson(Person p);
    List<Person> updatePerson(Integer id,Person p);
}
