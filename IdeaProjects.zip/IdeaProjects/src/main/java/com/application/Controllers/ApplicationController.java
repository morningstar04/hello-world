package com.application.Controllers;


import com.application.DAO.CustomRepoImpl;
import com.application.Models.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;



import java.util.List;

@RestController
public class ApplicationController {

    @Autowired
    private CustomRepoImpl customRepo;

    @RequestMapping("/")
    public String index(){
        return "Hello World!";
    }

    @RequestMapping("/persons")
    public List<Person> findAll(){
        return customRepo.findAll();
    }

    @RequestMapping(value = "/person/{id}",method = RequestMethod.GET)
    public Person findById(@PathVariable Integer id){
        return customRepo.findById(id);
    }

    @RequestMapping(value="/persons",method = RequestMethod.POST)
    public List<Person> insertPerson(@RequestBody Person p){
        return customRepo.insertPerson(p);
    }

    @RequestMapping(value="/person/{id}",method = RequestMethod.PUT)
    public List<Person> insertPerson(@PathVariable Integer id,@RequestBody Person p){
        return customRepo.updatePerson(id,p);
    }

}
